# License pending

This package intentionally does not assert a license on behalf of all
contributors. Before public upload, obtain contributor approval and replace this
file with the chosen license text. CC BY 4.0 is a common option for reusable
research datasets; code in the repository may require a separate software
license. This note is not legal advice.
